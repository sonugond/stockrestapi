﻿namespace restapi.stockContext
{
    public class Dbset<T>
    {
    }
}