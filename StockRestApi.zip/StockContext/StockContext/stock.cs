﻿namespace restapi.stockContext
{
    public class stock
    {
    }
}